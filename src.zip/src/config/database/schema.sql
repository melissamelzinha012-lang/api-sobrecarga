CREATE DATABASE IF NOT EXISTS ponte
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ponte;